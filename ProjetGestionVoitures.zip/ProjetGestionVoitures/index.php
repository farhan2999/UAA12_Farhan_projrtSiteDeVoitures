<?php
    session_start();
    require_once("Config/connectDataBase.php");
    require_once("Controller/indexController.php");
    require_once("Controller/userController.php");
