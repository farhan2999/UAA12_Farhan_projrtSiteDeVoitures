<header>
    <ul class="flexible justify-content-space-between ">
        <li class="menu"><a href="/">Acceuil</a></li>
        <li class="menu"><a href="inscription">Inscription</a></li>
        <li class="menu"><a href="connexion">Connexion</a></li>
    </ul>
</header>