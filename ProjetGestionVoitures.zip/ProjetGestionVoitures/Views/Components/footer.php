<footer class="flexible justify-content-space-between">
    <p class="p">Abuzour Farhan</p>
    <div class="non3 ">
        <a  href="https://www.instagram.com/centreastymoulin_namur/"><img class="imgFoo" id="padding" class="imageIcon non3" src="/Assets/IMG/instagram.png" alt="image instagram"></a>
        <a  href="https://www.facebook.com/login/?next=https%3A%2F%2Fwww.facebook.com%2FCentreAstyMoulin%2F%3Flocale%3Dfr_FR"><img class="imgFoo" id="padding" class="imageIcon non3" src="/Assets/IMG/facebook.png" alt="image facebook"></a>
    </div>
</footer>